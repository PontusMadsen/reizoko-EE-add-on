<?php

if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

use ExpressionEngine\Service\Addon\Module;

class Reizoko extends Module
{
    protected $addon_name = 'reizoko';
}